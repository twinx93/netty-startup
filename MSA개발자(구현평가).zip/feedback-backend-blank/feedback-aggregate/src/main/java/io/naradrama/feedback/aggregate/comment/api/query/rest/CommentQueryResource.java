/*
 COPYRIGHT (c) NEXTREE Inc. 2014
 This software is the proprietary of NEXTREE Inc.
 @since 2014. 6. 10.
*/
package io.naradrama.feedback.aggregate.comment.api.query.rest;

// TODO Implement RestController Component Class which implements CommentQueryFacade and receives CommentLogic, RdbQueryRequest<CommentJpo> as Dependency Injection
//  url
//  1. root : /aggregate/comment/query
//  2. base query : /
//  3. dynamic query with single result : /dynamic-single
//  4. dynamic query with multiple results : /dynamic-multi
public class CommentQueryResource {

}
