/*
 COPYRIGHT (c) NEXTREE Inc. 2014
 This software is the proprietary of NEXTREE Inc.
 @since 2014. 6. 10.
*/
package io.naradrama.feedback.facade.secure.aggregate.comment;

// TODO Extract Apis from CommentQueryResource which are used by front project
//  url
//   1. Replace 'aggregate' to 'secure' of origin url (e.g. /aggregate/comment/~ => /secure/comment/~)
public class CommentQuerySecureResource{
}
