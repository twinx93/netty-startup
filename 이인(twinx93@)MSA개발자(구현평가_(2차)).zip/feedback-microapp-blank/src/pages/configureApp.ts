
import moment from 'moment';


const configureApp = () => {
  //
  moment.locale('ko');
};

export default configureApp;
