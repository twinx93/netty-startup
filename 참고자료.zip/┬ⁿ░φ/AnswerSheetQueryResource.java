package io.naradrama.survey.aggregate.answer.api.query.rest;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import io.naradrama.survey.aggregate.answer.api.query.rest.AnswerSheetQueryFacade;
import io.naradrama.survey.aggregate.answer.store.AnswerSheetStore;
import io.naradrama.prologue.util.query.DocQueryRequest;
import io.naradrama.survey.aggregate.answer.store.mongo.document.AnswerSheetDoc;
import org.springframework.data.mongodb.core.MongoTemplate;
import io.naradrama.survey.aggregate.answer.api.query.query.AnswerSheetQuery;
import org.springframework.web.bind.annotation.RequestBody;
import io.naraplatform.daysman.daysboy.config.Daysboy;
import org.springframework.web.bind.annotation.PostMapping;
import io.naradrama.survey.aggregate.answer.api.query.query.AnswerSheetDynamicQuery;
import io.naradrama.survey.aggregate.answer.api.query.query.AnswerSheetsDynamicQuery;

@RestController
@RequestMapping("/aggregate/answer-sheet/query")
public class AnswerSheetQueryResource implements AnswerSheetQueryFacade {
    /* Autogen by nara studio */
    private final AnswerSheetStore answerSheetStore;
    private final DocQueryRequest<AnswerSheetDoc> request;

    public AnswerSheetQueryResource(AnswerSheetStore answerSheetStore, MongoTemplate mongoTemplate) {
        /* Autogen by nara studio */
        this.answerSheetStore = answerSheetStore;
        this.request = new DocQueryRequest<>(mongoTemplate);
    }

    @Override
    @Daysboy
    @PostMapping("/")
    public AnswerSheetQuery execute(@RequestBody AnswerSheetQuery answerSheetQuery) {
        /* Autogen by nara studio */
        answerSheetQuery.execute(answerSheetStore);
        return answerSheetQuery;
    }

    @Override
    @Daysboy
    @PostMapping("/dynamic-single")
    public AnswerSheetDynamicQuery execute(@RequestBody AnswerSheetDynamicQuery answerSheetDynamicQuery) {
        /* Autogen by nara studio */
        answerSheetDynamicQuery.execute(request);
        return answerSheetDynamicQuery;
    }

    @Override
    @Daysboy
    @PostMapping("/dynamic-multi")
    public AnswerSheetsDynamicQuery execute(@RequestBody AnswerSheetsDynamicQuery answerSheetsDynamicQuery) {
        /* Autogen by nara studio */
        answerSheetsDynamicQuery.execute(request);
        return answerSheetsDynamicQuery;
    }
}
