import React from 'react';
import { autobind, ReactComponent } from '@nara.drama/prologue';
import { NextRouter, withRouter } from 'next/router';
import { CommentList } from '~/comp/view';
import { Button, Container, SubActions } from '@nara.platform/react-ui';


interface Props {
  router: NextRouter;
}

@autobind
class CommentListPage extends ReactComponent<Props> {
  //
  routeToRegistration() {
    //
    const { router } = this.props;

    router.push('/comments/new');
  }

  render() {
    //
    const sourceEntityId = "testFeedbackId";
    const sourceEntityName = 'Namoosori';
    const userId = 'manager@nextree.io';
    const writerName = 'testName';

    return (
      <Container>
        <CommentList
          sourceEntityId={sourceEntityId}
          sourceEntityName={sourceEntityName}
          userId={userId}
          writerName={writerName}
        >
          <SubActions>
            <SubActions.Left>
              <Button onClick={this.routeToRegistration}>
                Registration
              </Button>
            </SubActions.Left>
          </SubActions>
          <CommentList.Header />
          <CommentList.Content />
          <CommentList.ActionButton />
        </CommentList>
      </Container>
      );
  }
}

export default withRouter(CommentListPage);
