/*
 COPYRIGHT (c) NEXTREE Inc. 2014
 This software is the proprietary of NEXTREE Inc.
 @since 2014. 6. 10.
*/
package io.naradrama.feedback.aggregate.comment.domain.logic;

import io.naradrama.feedback.aggregate.comment.api.command.command.CommentCommand;
import io.naradrama.feedback.aggregate.comment.domain.entity.Comment;
import io.naradrama.feedback.aggregate.comment.domain.entity.sdo.CommentCdo;
import io.naradrama.feedback.aggregate.comment.store.CommentStore;
import io.naradrama.prologue.domain.NameValueList;
import io.naradrama.prologue.domain.Offset;
import io.naradrama.prologue.domain.cqrs.FailureMessage;
import io.naradrama.prologue.domain.cqrs.command.CommandResponse;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;
import java.lang.String;

@Service
@Transactional
public class CommentLogic {
    // Autogen by nara studio
    private final CommentStore commentStore;

    public CommentLogic(CommentStore commentStore) {
        /* Autogen by nara studio */
        this.commentStore = commentStore;
    }

    public CommentCommand routeCommand(CommentCommand command) {
        switch(/* Autogen by nara studio */
        command.getCqrsBaseCommandType()) {
            case Register:
                if (command.getCommentCdos().size() > 0) {
                    List<String> entityIds = this.registerComments(command.getCommentCdos());
                    command.setCommandResponse(new CommandResponse(entityIds));
                } else {
                    String entityId = this.registerComment(command.getCommentCdo());
                    command.setCommandResponse(new CommandResponse(entityId));
                }
                break;
            case Modify:
                this.modifyComment(command.getCommentId(), command.getNameValues());
                command.setCommandResponse(new CommandResponse(command.getCommentId()));
                break;
            case Remove:
                this.removeComment(command.getCommentId());
                command.setCommandResponse(new CommandResponse(command.getCommentId()));
                break;
            default:
                command.setFailureMessage(new FailureMessage(new Throwable("CommandType must be Register, Modify or Remove")));
        }
        return command;
    }

    public String registerComment(CommentCdo commentCdo) {
        //
        // TODO
        //  1. Save entity from cdo when entity was not exists
        //  2. Return registered entity's id
        String id = null;
        Comment comment = new Comment(commentCdo);
        id = comment.getId();
        if(commentStore.exists(id)){
            throw new IllegalArgumentException("comment already exists. " + id);
        }
        commentStore.create(comment);
        return id;
    }

    public List<String> registerComments(List<CommentCdo> commentCdos) {
        //
        // TODO
        //  1. Register entities from cdo list
        //  2. Return registered entity's id list
        List<String> result = commentCdos.stream().map(commentCdo -> this.registerComment(commentCdo)).collect(Collectors.toList());
        return result;
    }

    public Comment findComment(String commentId) {
        //
        // TODO
        //  1. Find entity by optimal query condition
        //  2. If result was empty, throw exception
        Comment comment = commentStore.retrieve(commentId);
        if (comment == null) {
            throw new NoSuchElementException("comment id: " + commentId);
        }
        return comment;
    }

    public List<Comment> findAllComment(Offset offset) {
        //
        // TODO
        //  1. Find entities by optimal query conditions
        List<Comment> comments = commentStore.retrieveAll(offset); 
        return comments;
    }

    public void modifyComment(String commentId, NameValueList nameValues) {
        //
        // TODO
        //  1. Modify entity
        Comment comment = findComment(commentId);
        comment.modifyValues(nameValues);
        commentStore.update(comment);
    }

    public void modifyComment(Comment comment) {
        //
        // TODO
        //  1. Modify entity
        Comment foundComment = findComment(comment.getId());  
        commentStore.update(foundComment);
    }

    public void removeComment(String commentId) {
        //
        // TODO
        //  1. Remove entity
        Comment foundComment = findComment(commentId);
        commentStore.delete(foundComment);
    }

    public boolean exists(String commentId) {
        //
        // TODO
        //  1. Check existence
        boolean result = commentStore.exists(commentId);
        return result;
    }
}
