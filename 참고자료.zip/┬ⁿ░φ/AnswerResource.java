package io.naradrama.survey.aggregate.answer.api.command.rest;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import io.naradrama.survey.aggregate.answer.api.command.rest.AnswerFacade;
import io.naradrama.survey.aggregate.answer.domain.logic.AnswerSheetLogic;
import io.naradrama.survey.aggregate.answer.api.command.command.AnswerSheetCommand;
import org.springframework.web.bind.annotation.RequestBody;
import io.naraplatform.daysman.daysboy.config.Daysboy;
import org.springframework.web.bind.annotation.PostMapping;
import io.naradrama.survey.aggregate.answer.domain.logic.EvaluationSheetLogic;
import io.naradrama.survey.aggregate.answer.api.command.command.EvaluationSheetCommand;

@RestController
@RequestMapping("/aggregate/answer")
public class AnswerResource implements AnswerFacade {
    private final AnswerSheetLogic answerSheetLogic; // Autogen by nara studio
    private final EvaluationSheetLogic evaluationSheetLogic;

    public AnswerResource(AnswerSheetLogic answerSheetLogic, EvaluationSheetLogic evaluationSheetLogic) {
        /* Autogen by nara studio */
        this.answerSheetLogic = answerSheetLogic;
        this.evaluationSheetLogic = evaluationSheetLogic;
    }

    @Override
    @Daysboy
    @PostMapping("/answer-sheet/command")
    public AnswerSheetCommand executeAnswerSheet(@RequestBody AnswerSheetCommand answerSheetCommand) {
        return /* Autogen by nara studio */
        answerSheetLogic.routeCommand(answerSheetCommand);
    }

    @Override
    @Daysboy
    @PostMapping("/evaluation-sheet/command")
    public EvaluationSheetCommand executeEvaluationSheet(@RequestBody EvaluationSheetCommand evaluationSheetCommand) {
        /* Autogen by nara studio */
        return evaluationSheetLogic.routeCommand(evaluationSheetCommand);
    }
}
