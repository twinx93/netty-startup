package io.naradrama.survey.aggregate.form.store.mongo;

import io.naradrama.prologue.domain.Offset;
import io.naradrama.survey.aggregate.form.domain.entity.SurveyForm;
import io.naradrama.survey.aggregate.form.domain.entity.vo.FormState;
import io.naradrama.survey.aggregate.form.store.SurveyFormStore;
import io.naradrama.survey.aggregate.form.store.mongo.document.SurveyFormDoc;
import io.naradrama.survey.aggregate.form.store.mongo.repository.SurveyFormMongoRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class SurveyFormMongoStore implements SurveyFormStore {
    /* Autogen by nara studio */
    private final SurveyFormMongoRepository surveyFormMongoRepository;

    public SurveyFormMongoStore(SurveyFormMongoRepository surveyFormMongoRepository) {
        /* Autogen by nara studio */
        this.surveyFormMongoRepository = surveyFormMongoRepository;
    }

    @Override
    public void create(SurveyForm surveyForm) {
        /* Autogen by nara studio */
        SurveyFormDoc surveyFormDoc = new SurveyFormDoc(surveyForm);
        surveyFormMongoRepository.save(surveyFormDoc);
    }

    @Override
    public SurveyForm retrieve(String id) {
        /* Autogen by nara studio */
        Optional<SurveyFormDoc> surveyFormDoc = surveyFormMongoRepository.findById(id);
        return surveyFormDoc.map(SurveyFormDoc::toDomain).orElse(null);
    }

    @Override
    public void update(SurveyForm surveyForm) {
        /* Autogen by nara studio */
        SurveyFormDoc surveyFormDoc = new SurveyFormDoc(surveyForm);
        surveyFormMongoRepository.save(surveyFormDoc);
    }

    @Override
    public void delete(SurveyForm surveyForm) {
        /* Autogen by nara studio */
        surveyFormMongoRepository.deleteById(surveyForm.getId());
    }

    @Override
    public void delete(String id) {
        /* Autogen by nara studio */
        surveyFormMongoRepository.deleteById(id);
    }

    @Override
    public boolean exists(String id) {
        /* Autogen by nara studio */
        return surveyFormMongoRepository.existsById(id);
    }

    @Override
    public boolean existsByManagementNo(String managementNo) {
        return surveyFormMongoRepository.existsByManagementNo(managementNo);
    }

    @Override
    public List<SurveyForm> retrieveAllByFormState(FormState formState, Offset offset) {
        Pageable pageable = this.createPageable(offset);
        return surveyFormMongoRepository.findAllByFormState(formState).stream().map(SurveyFormDoc::toDomain).collect(Collectors.toList());
    }

    private Pageable createPageable(Offset offset) {
        /* Autogen by nara studio */
        if (offset.getSortDirection() != null && offset.getSortingField() != null) {
            return PageRequest.of(offset.page(), offset.limit(), (offset.ascendingSort() ? Sort.Direction.ASC : Sort.Direction.DESC), offset.getSortingField());
        } else {
            return PageRequest.of(offset.page(), offset.limit());
        }
    }
}
