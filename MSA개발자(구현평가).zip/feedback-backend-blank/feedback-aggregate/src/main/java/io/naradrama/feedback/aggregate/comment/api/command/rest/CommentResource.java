/*
 COPYRIGHT (c) NEXTREE Inc. 2014
 This software is the proprietary of NEXTREE Inc.
 @since 2014. 6. 10.
*/
/*
 COPYRIGHT (c) NEXTREE Inc. 2014
 This software is the proprietary of NEXTREE Inc.
 @since 2014. 6. 10.
*/
package io.naradrama.feedback.aggregate.comment.api.command.rest;

// TODO Implement RestController Component which implements CommandFacade and receives CommentLogic as Dependency Injection
//  url
//  1. root : /aggregate/comment
//  2. command with Comment : /comment/command
public class CommentResource {
}
