/*
 COPYRIGHT (c) NEXTREE Inc. 2014
 This software is the proprietary of NEXTREE Inc.
 @since 2014. 6. 10.
*/
package io.naradrama.feedback.flow.comment.domain.logic;

import io.naradrama.feedback.aggregate.comment.domain.entity.sdo.CommentCdo;
import io.naradrama.feedback.aggregate.comment.domain.logic.CommentLogic;
import io.naradrama.feedback.flow.comment.api.command.command.RegisterCommentCommand;
import io.naradrama.feedback.flow.comment.api.command.command.RemoveCommentCommand;
import io.naradrama.prologue.domain.cqrs.command.CommandResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@RequiredArgsConstructor
public class CommentFlowLogic {
    //
    private final CommentLogic commentLogic;

    public RegisterCommentCommand registerComment(RegisterCommentCommand command) {
        //
        CommentCdo commentCdo = command.getCommentCdo();

        String commentId = commentLogic.registerComment(commentCdo);

        command.setCommandResponse(new CommandResponse(commentId));
        return command;
    }

    public RemoveCommentCommand removeComment(RemoveCommentCommand command) {
        //
        String commentId = command.getCommentId();
        commentLogic.findComment(commentId);

        command.setCommandResponse(new CommandResponse(commentId));
        return command;
    }
}
