
interface CommentListContextParams {
  //
  init: () => void;
}

export default CommentListContextParams;
