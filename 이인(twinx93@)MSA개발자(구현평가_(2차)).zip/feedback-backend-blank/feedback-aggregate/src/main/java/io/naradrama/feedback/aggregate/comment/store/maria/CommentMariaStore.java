/*
 COPYRIGHT (c) NEXTREE Inc. 2014
 This software is the proprietary of NEXTREE Inc.
 @since 2014. 6. 10.
*/
package io.naradrama.feedback.aggregate.comment.store.maria;

import io.naradrama.feedback.aggregate.comment.domain.entity.Comment;
import io.naradrama.feedback.aggregate.comment.store.CommentStore;
import io.naradrama.feedback.aggregate.comment.store.maria.jpo.CommentJpo;
import io.naradrama.feedback.aggregate.comment.store.maria.repository.CommentMariaRepository;
import io.naradrama.prologue.domain.Offset;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

// TODO Implement Repository Component which implements CommentStore and receives CommentMariaRepository as Dependency Injection
@Repository
public class CommentMariaStore implements CommentStore{
    
    private final CommentMariaRepository commentMariaRepository;

    public CommentMariaStore(CommentMariaRepository commentMariaRepository){
        this.commentMariaRepository = commentMariaRepository;
    }
    
    //
    private Pageable createPageable(Offset offset) {
        /* Autogen by nara studio */
        if (offset.getSortDirection() != null && offset.getSortingField() != null) {
            return PageRequest.of(offset.page(), offset.limit(), (offset.ascendingSort() ? Sort.Direction.ASC : Sort.Direction.DESC), offset.getSortingField());
        } else {
            return PageRequest.of(offset.page(), offset.limit());
        }
    }

    @Override
    public void create(Comment comment) {
        // TODO Auto-generated method stub
        CommentJpo commentJpo = new CommentJpo(comment);
        commentMariaRepository.save(commentJpo);
    }

    @Override
    public Comment retrieve(String id) {
        // TODO Auto-generated method stub
        Optional<CommentJpo> commentJpo = commentMariaRepository.findById(id);
        Comment comment = commentJpo.map(CommentJpo::toDomain).orElse(null);
        return comment;        
    }

    @Override
    public List<Comment> retrieveAll(Offset offset) {
        // TODO Auto-generated method stub
        Pageable pageable = this.createPageable(offset);
        List<Comment> comments = commentMariaRepository.findAll(pageable).stream().map(CommentJpo::toDomain).collect(Collectors.toList());        
        return comments;
    }

    @Override
    public void update(Comment comment) {
        // TODO Auto-generated method stub
        CommentJpo commentJpo = new CommentJpo(comment);
        commentMariaRepository.save(commentJpo);
    }

    @Override
    public void delete(Comment comment) {
        // TODO Auto-generated method stub
        commentMariaRepository.deleteById(comment.getId());
    }

    @Override
    public void delete(String id) {
        // TODO Auto-generated method stub
        commentMariaRepository.deleteById(id);
    }

    @Override
    public boolean exists(String id) {
        // TODO Auto-generated method stub
        boolean result = commentMariaRepository.existsById(id);
        return result;
    }

    @Override
    public List<Comment> retrieveAllByFeedbackId(String feedbackId) {
        // TODO Auto-generated method stub        
        return commentMariaRepository.findAllByFeedbackId(feedbackId).stream().map(CommentJpo::toDomain).collect(Collectors.toList());
        // return null;
    }

    @Override
    public List<Comment> deleteByFeedbackId(String feedbackId) {
        // TODO Auto-generated method stub        
        return commentMariaRepository.removeByFeedbackId(feedbackId);
        // return null;
    }
}
