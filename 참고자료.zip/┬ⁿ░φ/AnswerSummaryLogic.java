package io.naradrama.survey.aggregate.analysis.domain.logic;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import io.naradrama.survey.aggregate.analysis.domain.logic.SurveySummaryLogic;
import io.naradrama.survey.aggregate.analysis.store.AnswerSummaryStore;
import io.naraplatform.daysman.mediator.spec.EventStreamService;
import io.naradrama.survey.aggregate.analysis.api.command.command.AnswerSummaryCommand;
import io.naradrama.prologue.domain.cqrs.command.CommandResponse;
import io.naradrama.prologue.domain.cqrs.FailureMessage;
import java.lang.String;
import io.naradrama.survey.aggregate.analysis.domain.entity.sdo.AnswerSummaryCdo;
import java.util.NoSuchElementException;
import io.naradrama.survey.aggregate.analysis.domain.event.AnswerSummaryEvent;
import io.naradrama.survey.aggregate.analysis.domain.entity.SurveySummary;
import io.naradrama.prologue.domain.tenant.AudienceKey;
import java.util.List;
import java.util.stream.Collectors;
import io.naradrama.survey.aggregate.analysis.domain.entity.AnswerSummary;
import io.naradrama.prologue.domain.NameValueList;

@Service
@Transactional
public class AnswerSummaryLogic {
    private final SurveySummaryLogic surveySummaryLogic; // Autogen by nara studio
    private final AnswerSummaryStore answerSummaryStore;
    private final EventStreamService eventStreamService;

    public AnswerSummaryLogic(SurveySummaryLogic surveySummaryLogic, AnswerSummaryStore answerSummaryStore, EventStreamService eventStreamService) {
        /* Autogen by nara studio */
        this.surveySummaryLogic = surveySummaryLogic;
        this.answerSummaryStore = answerSummaryStore;
        this.eventStreamService = eventStreamService;
    }

    public AnswerSummaryCommand routeCommand(AnswerSummaryCommand command) {
        switch(/* Autogen by nara studio */
        command.getCqrsBaseCommandType()) {
            case Register:
                if (command.getAnswerSummaryCdos().size() > 0) {
                    List<String> entityIds = this.registerAnswerSummarys(command.getAnswerSummaryCdos());
                    command.setCommandResponse(new CommandResponse(entityIds));
                } else {
                    String entityId = this.registerAnswerSummary(command.getAnswerSummaryCdo());
                    command.setCommandResponse(new CommandResponse(entityId));
                }
                break;
            case Modify:
                this.modifyAnswerSummary(command.getAnswerSummaryId(), command.getNameValues());
                command.setCommandResponse(new CommandResponse(command.getAnswerSummaryId()));
                break;
            case Remove:
                this.removeAnswerSummary(command.getAnswerSummaryId());
                command.setCommandResponse(new CommandResponse(command.getAnswerSummaryId()));
                break;
            default:
                command.setFailureMessage(new FailureMessage(new Throwable("CommandType must be Register, Modify or Remove")));
        }
        return command;
    }

    public String registerAnswerSummary(AnswerSummaryCdo answerSummaryCdo) {
        /* Autogen by nara studio */
        AudienceKey audienceKey = new AudienceKey();
        AnswerSummary answerSummary = new AnswerSummary(answerSummaryCdo, answerSummaryCdo.getAudienceKey());
        if (answerSummaryStore.exists(answerSummary.getId())) {
            throw new IllegalArgumentException("answerSummary already exists. " + answerSummary.getId());
        }
        answerSummaryStore.create(answerSummary);
        AnswerSummaryEvent answerSummaryEvent = AnswerSummaryEvent.newAnswerSummaryRegisteredEvent(answerSummary);
        eventStreamService.produce(answerSummaryEvent);
        return answerSummary.getId();
    }

    public List<String> registerAnswerSummarys(List<AnswerSummaryCdo> answerSummaryCdos) {
        return /* Autogen by nara studio */
        answerSummaryCdos.stream().map(answerSummaryCdo -> this.registerAnswerSummary(answerSummaryCdo)).collect(Collectors.toList());
    }

    public AnswerSummary findAnswerSummary(String answerSummaryId) {
        /* Autogen by nara studio */
        AnswerSummary answerSummary = answerSummaryStore.retrieve(answerSummaryId);
        if (answerSummary == null) {
            throw new NoSuchElementException("AnswerSummary id: " + answerSummaryId);
        }
        return answerSummary;
    }

    public void modifyAnswerSummary(String answerSummaryId, NameValueList nameValues) {
        /* Autogen by nara studio */
        AnswerSummary answerSummary = findAnswerSummary(answerSummaryId);
        answerSummary.modifyValues(nameValues);
        answerSummaryStore.update(answerSummary);
        AnswerSummaryEvent answerSummaryEvent = AnswerSummaryEvent.newAnswerSummaryModifiedEvent(answerSummaryId, nameValues);
        eventStreamService.produce(answerSummaryEvent);
    }

    public void modifyAnswerSummary(AnswerSummary answerSummary) {
        // Check existence
        AnswerSummary foundAnswerSummary = findAnswerSummary(answerSummary.getId());
        answerSummaryStore.update(answerSummary);
        AnswerSummaryEvent answerSummaryEvent = AnswerSummaryEvent.newAnswerSummaryModifiedEvent(answerSummary);
        eventStreamService.produce(answerSummaryEvent);
    }

    public void removeAnswerSummary(String answerSummaryId) {
        /* Autogen by nara studio */
        AnswerSummary answerSummary = findAnswerSummary(answerSummaryId);
        answerSummaryStore.delete(answerSummary);
        AnswerSummaryEvent answerSummaryEvent = AnswerSummaryEvent.newAnswerSummaryRemovedEvent(answerSummary);
        eventStreamService.produce(answerSummaryEvent);
    }

    public boolean existsAnswerSummary(String answerSummaryId) {
        return /* Autogen by nara studio */
        answerSummaryStore.exists(answerSummaryId);
    }

    public void handleEventForProjection(AnswerSummaryEvent answerSummaryEvent) {
        switch(/* Autogen by nara studio */
        answerSummaryEvent.getCqrsDataEventType()) {
            case Registered:
                answerSummaryStore.create(answerSummaryEvent.getAnswerSummary());
                break;
            case Modified:
                AnswerSummary answerSummary = answerSummaryStore.retrieve(answerSummaryEvent.getAnswerSummaryId());
                answerSummary.modifyValues(answerSummaryEvent.getNameValues());
                answerSummaryStore.update(answerSummary);
                break;
            case Removed:
                answerSummaryStore.delete(answerSummaryEvent.getAnswerSummaryId());
                break;
        }
    }
}
