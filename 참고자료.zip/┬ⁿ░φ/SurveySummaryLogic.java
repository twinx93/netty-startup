package io.naradrama.survey.aggregate.analysis.domain.logic;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import io.naradrama.survey.aggregate.analysis.store.SurveySummaryStore;
import io.naraplatform.daysman.mediator.spec.EventStreamService;
import io.naradrama.survey.aggregate.analysis.api.command.command.SurveySummaryCommand;
import io.naradrama.prologue.domain.cqrs.command.CommandResponse;
import io.naradrama.prologue.domain.cqrs.FailureMessage;
import java.lang.String;
import io.naradrama.survey.aggregate.analysis.domain.entity.sdo.SurveySummaryCdo;
import io.naradrama.survey.aggregate.analysis.domain.event.SurveySummaryEvent;
import io.naradrama.prologue.domain.tenant.AudienceKey;
import java.util.List;
import java.util.stream.Collectors;
import io.naradrama.survey.aggregate.analysis.domain.entity.SurveySummary;
import java.util.NoSuchElementException;
import io.naradrama.prologue.domain.NameValueList;

@Service
@Transactional
public class SurveySummaryLogic {
    private final SurveySummaryStore surveySummaryStore; // Autogen by nara studio
    private final EventStreamService eventStreamService;

    public SurveySummaryLogic(SurveySummaryStore surveySummaryStore, EventStreamService eventStreamService) {
        /* Autogen by nara studio */
        this.surveySummaryStore = surveySummaryStore;
        this.eventStreamService = eventStreamService;
    }

    public SurveySummaryCommand routeCommand(SurveySummaryCommand command) {
        switch(/* Autogen by nara studio */
        command.getCqrsBaseCommandType()) {
            case Register:
                if (command.getSurveySummaryCdos().size() > 0) {
                    List<String> entityIds = this.registerSurveySummarys(command.getSurveySummaryCdos());
                    command.setCommandResponse(new CommandResponse(entityIds));
                } else {
                    String entityId = this.registerSurveySummary(command.getSurveySummaryCdo());
                    command.setCommandResponse(new CommandResponse(entityId));
                }
                break;
            case Modify:
                this.modifySurveySummary(command.getSurveySummaryId(), command.getNameValues());
                command.setCommandResponse(new CommandResponse(command.getSurveySummaryId()));
                break;
            case Remove:
                this.removeSurveySummary(command.getSurveySummaryId());
                command.setCommandResponse(new CommandResponse(command.getSurveySummaryId()));
                break;
            default:
                command.setFailureMessage(new FailureMessage(new Throwable("CommandType must be Register, Modify or Remove")));
        }
        return command;
    }

    public String registerSurveySummary(SurveySummaryCdo surveySummaryCdo) {
        /* Autogen by nara studio */
        SurveySummary surveySummary = new SurveySummary(surveySummaryCdo, surveySummaryCdo.getAudienceKey());
        if (surveySummaryStore.exists(surveySummary.getId())) {
            throw new IllegalArgumentException("surveySummary already exists. " + surveySummary.getId());
        }
        surveySummaryStore.create(surveySummary);
        SurveySummaryEvent surveySummaryEvent = SurveySummaryEvent.newSurveySummaryRegisteredEvent(surveySummary);
        eventStreamService.produce(surveySummaryEvent);
        return surveySummary.getId();
    }

    public List<String> registerSurveySummarys(List<SurveySummaryCdo> surveySummaryCdos) {
        return /* Autogen by nara studio */
        surveySummaryCdos.stream().map(surveySummaryCdo -> this.registerSurveySummary(surveySummaryCdo)).collect(Collectors.toList());
    }

    public SurveySummary findSurveySummary(String surveySummaryId) {
        /* Autogen by nara studio */
        SurveySummary surveySummary = surveySummaryStore.retrieve(surveySummaryId);
        if (surveySummary == null) {
            throw new NoSuchElementException("SurveySummary id: " + surveySummaryId);
        }
        return surveySummary;
    }

    public void modifySurveySummary(String surveySummaryId, NameValueList nameValues) {
        /* Autogen by nara studio */
        SurveySummary surveySummary = findSurveySummary(surveySummaryId);
        surveySummary.modifyValues(nameValues);
        surveySummaryStore.update(surveySummary);
        SurveySummaryEvent surveySummaryEvent = SurveySummaryEvent.newSurveySummaryModifiedEvent(surveySummaryId, nameValues);
        eventStreamService.produce(surveySummaryEvent);
    }

    public void modifySurveySummary(SurveySummary surveySummary) {
        // Check existence
        SurveySummary foundSurveySummary = findSurveySummary(surveySummary.getId());
        surveySummaryStore.update(surveySummary);
        SurveySummaryEvent surveySummaryEvent = SurveySummaryEvent.newSurveySummaryModifiedEvent(surveySummary);
        eventStreamService.produce(surveySummaryEvent);
    }

    public void removeSurveySummary(String surveySummaryId) {
        /* Autogen by nara studio */
        SurveySummary surveySummary = findSurveySummary(surveySummaryId);
        surveySummaryStore.delete(surveySummary);
        SurveySummaryEvent surveySummaryEvent = SurveySummaryEvent.newSurveySummaryRemovedEvent(surveySummary.getId());
        eventStreamService.produce(surveySummaryEvent);
    }

    public boolean existsSurveySummary(String surveySummaryId) {
        return /* Autogen by nara studio */
        surveySummaryStore.exists(surveySummaryId);
    }

    public void handleEventForProjection(SurveySummaryEvent surveySummaryEvent) {
        switch(/* Autogen by nara studio */
        surveySummaryEvent.getCqrsDataEventType()) {
            case Registered:
                surveySummaryStore.create(surveySummaryEvent.getSurveySummary());
                break;
            case Modified:
                SurveySummary surveySummary = surveySummaryStore.retrieve(surveySummaryEvent.getSurveySummaryId());
                surveySummary.modifyValues(surveySummaryEvent.getNameValues());
                surveySummaryStore.update(surveySummary);
                break;
            case Removed:
                surveySummaryStore.delete(surveySummaryEvent.getSurveySummaryId());
                break;
        }
    }
}
