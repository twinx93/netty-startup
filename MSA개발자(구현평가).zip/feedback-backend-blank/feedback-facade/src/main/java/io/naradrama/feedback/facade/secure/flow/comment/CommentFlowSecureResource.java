/*
 COPYRIGHT (c) NEXTREE Inc. 2014
 This software is the proprietary of NEXTREE Inc.
 @since 2014. 6. 10.
*/
package io.naradrama.feedback.facade.secure.flow.comment;

// TODO Extract Apis from CommentFlowResource which are used by front project
//  url
//   1. replace 'flow' to 'secure' of origin url (e.g. /flow/comment-flow/~ => /secure/comment-flow/~)
public class CommentFlowSecureResource{
    }
