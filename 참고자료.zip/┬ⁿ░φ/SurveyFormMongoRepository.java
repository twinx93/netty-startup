/*
 COPYRIGHT (c) NEXTREE Inc. 2014
 This software is the proprietary of NEXTREE Inc.
 @since 2014. 6. 10.
*/
package io.naradrama.survey.aggregate.form.store.mongo.repository;

import io.naradrama.survey.aggregate.form.domain.entity.vo.FormState;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import io.naradrama.survey.aggregate.form.store.mongo.document.SurveyFormDoc;

import java.util.List;

public interface SurveyFormMongoRepository extends MongoRepository<SurveyFormDoc, String> {
    /* Autogen by nara studio */
    boolean existsByManagementNo(String managementNo);
    List<SurveyFormDoc> findAllByFormState(FormState formState, Pageable pageable);
    List<SurveyFormDoc> findAllByFormState(FormState formState);
}
