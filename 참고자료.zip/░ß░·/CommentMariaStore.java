/*
 COPYRIGHT (c) NEXTREE Inc. 2014
 This software is the proprietary of NEXTREE Inc.
 @since 2014. 6. 10.
*/
package io.naradrama.feedback.aggregate.comment.store.maria;

import io.naradrama.feedback.aggregate.comment.domain.entity.Comment;
import io.naradrama.feedback.aggregate.comment.store.CommentStore;
import io.naradrama.feedback.aggregate.comment.store.maria.jpo.CommentJpo;
import io.naradrama.feedback.aggregate.comment.store.maria.repository.CommentMariaRepository;
import io.naradrama.prologue.domain.Offset;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

// TODO Implement Repository Component which implements CommentStore and receives CommentMariaRepository as Dependency Injection
@Repository
public class CommentMariaStore implements CommentStore {
    //
    private final CommentMariaRepository commentMariaRepository;

    public CommentMariaStore(CommentMariaRepository commentMariaRepository) {
        /* Autogen by nara studio */
        this.commentMariaRepository = commentMariaRepository;
    }

    private Pageable createPageable(Offset offset) {
        /* Autogen by nara studio */
        if (offset.getSortDirection() != null && offset.getSortingField() != null) {
            return PageRequest.of(offset.page(), offset.limit(), (offset.ascendingSort() ? Sort.Direction.ASC : Sort.Direction.DESC), offset.getSortingField());
        } else {
            return PageRequest.of(offset.page(), offset.limit());
        }
    }

    @Override
    public void create(Comment comment) {
        CommentJpo commentJpo = new CommentJpo(comment);
        commentMariaRepository.save(commentJpo);
    }

    @Override
    public Comment retrieve(String id) {
        Optional<CommentJpo> commentJpo = commentMariaRepository.findById(id);
        return commentJpo.map(CommentJpo::toDomain).orElse(null);
    }

    @Override
    public List<Comment> retrieveAll(Offset offset) {
        Pageable pageable = this.createPageable(offset);
        return commentMariaRepository.findAll(pageable)
                .stream()
                .map(CommentJpo::toDomain)
                .collect(toList());
    }

    @Override
    public void update(Comment comment) {
        CommentJpo commentJpo = new CommentJpo(comment);
        commentMariaRepository.save(commentJpo);
    }

    @Override
    public void delete(Comment comment) {
        System.out.println("comment.getId : " + comment.getId());

        commentMariaRepository.deleteById(comment.getId());
    }

    @Override
    public void delete(String id) {
        System.out.println("comment.id : " + id);

        commentMariaRepository.deleteById(id);
    }

    @Override
    public boolean exists(String id) {
        return commentMariaRepository.existsById(id);
    }

//    @Override
//    public List<Comment> retrieveAllByFeedbackId(Comment comment, Offset offset) {
//        Pageable pageable = this.createPageable(offset);
//        return commentMariaRepository.findAllByComment(comment.getFeedbackId(), pageable).stream().map(CommentJpo::toDomain).collect(Collectors.toList());
//    }

    @Override
    public List<Comment> retrieveAllByFeedbackId(String feedbackId) {
        return commentMariaRepository.findAllByFeedbackId(feedbackId).stream().map(CommentJpo::toDomain).collect(toList());
    }

    @Override
    public List<Comment> deleteByFeedbackId(String feedbackId) {
        return null;
    }
}
